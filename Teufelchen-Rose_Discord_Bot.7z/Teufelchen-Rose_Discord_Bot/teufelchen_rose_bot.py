import discord
import asyncio
import os
from googleapiclient.discovery import build
from dotenv import load_dotenv

# .env laden
load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
DISCORD_CHANNEL_ID = int(os.getenv("DISCORD_CHANNEL_ID"))
SECOND_DISCORD_CHANNEL_ID = int(os.getenv("SECOND_DISCORD_CHANNEL_ID"))  # Neuer Discord-Kanal für zweiten YouTube-Kanal
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")
CHANNEL_ID = os.getenv("CHANNEL_ID")
SECOND_CHANNEL_ID = os.getenv("SECOND_CHANNEL_ID")  # Zweiter YouTube-Kanal
ROLE_ID = int(os.getenv("ROLE_ID"))

YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

intents = discord.Intents.default()
client = discord.Client(intents=intents)

youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey=YOUTUBE_API_KEY)

last_video_id = None
last_second_video_id = None  # Zweite Video-ID für den zweiten Kanal

async def check_new_video(channel_id, last_video_id, discord_channel_id, is_second_channel=False):
    """Überprüft, ob es neue Videos auf dem angegebenen YouTube-Kanal gibt"""
    await client.wait_until_ready()
    channel = client.get_channel(discord_channel_id)

    while not client.is_closed():
        try:
            # Überprüft den YouTube-Kanal
            channels_response = youtube.channels().list(
                part="contentDetails",
                id=channel_id
            ).execute()

            uploads_playlist_id = channels_response["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]

            playlist_items_response = youtube.playlistItems().list(
                part="snippet",
                playlistId=uploads_playlist_id,
                maxResults=1
            ).execute()

            latest_video = playlist_items_response["items"][0]["snippet"]
            video_id = latest_video["resourceId"]["videoId"]
            video_title = latest_video["title"]
            video_url = f"https://www.youtube.com/watch?v={video_id}"

            # Wenn ein neues Video gefunden wurde, postet der Bot eine Nachricht
            if video_id != last_video_id:
                last_video_id = video_id

                if is_second_channel:
                    # Nachricht für den zweiten Kanal (z. B. MMD)
                    message = (
                        f"🎬 **Neues MMD-Video online!**\n"
                        f"📌 Titel: ***{video_title}***\n"  # Titel des YT Videos fett und kursiv
                        f"🔗 Link: {video_url}\n"
                        f"||<@&{ROLE_ID}>||"
                    )
                else:
                    # Nachricht für den ersten Kanal (z. B. YouTube News)
                    message = (
                        f"📢 **Neues YouTube News-Video online!**\n"
                        f"📌 Titel: ***{video_title}***\n"  # Titel des YT Videos fett und kursiv
                        f"🔗 Link: {video_url}\n"
                        f"||<@&{ROLE_ID}>||"
                    )

                await channel.send(message)
            else:
                print("🔄 Kein neues Video gefunden.")

        except Exception as e:
            print(f"❌ Fehler beim Abrufen der YouTube-Daten: {e}")

        await asyncio.sleep(3600)  # Alle 60 Minuten prüfen (Angabe in Sec)

    return last_video_id

async def rotate_status():
    """Aktualisiert den Status des Bots"""
    await client.wait_until_ready()
    
    statuses = [
        ("🕵️", "Status 1"), # Vergib hier die Status Meldungen die Angezeigt werden wenn der Bot Aktiv ist. Die Status Meldung wird im 10min Rytmus geändert.
        ("📡", "Status 2"),
        ("🎧", "Status 3"),
        ("💤", "Status 4"),
    ]

    while not client.is_closed():
        for emoji, text in statuses:
            activity = discord.CustomActivity(name=f"{emoji} {text}")
            await client.change_presence(activity=activity)
            await asyncio.sleep(600)  # 10 Minuten pro Status (Angabe in Sec)

@client.event
async def on_ready():
    print(f"✅ Bot eingeloggt als {client.user}")
    
    # 🕵️ Status rotieren lassen
    client.loop.create_task(rotate_status())

@client.event
async def setup_hook():
    # Überprüft die Videos des ersten Kanals (YouTube News)
    client.loop.create_task(check_new_video(CHANNEL_ID, last_video_id, DISCORD_CHANNEL_ID, is_second_channel=False))
    
    # Überprüft die Videos des zweiten Kanals (MMD)
    client.loop.create_task(check_new_video(SECOND_CHANNEL_ID, last_second_video_id, SECOND_DISCORD_CHANNEL_ID, is_second_channel=True))

async def main():
    async with client:
        await client.start(DISCORD_TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
